<template>
    <!-- CONTACT US -->
    <section class="max-w-screen-xl my-14 mx-auto flex flex-col relative">
        <h1 class="text-[#1E0342] font-semibold text-[2rem] md:text-[3rem] text-center relative">
            Contact Us
        </h1>
        <div class="flex md:mt-20">
            <div class="flex-1 flex-col p-8">
                <div class="flex py-10">
                    <div class="border rounded-[10rem] border-[#1E0342] p-3 md:min-w-[5rem] md:min-h-[5rem] w-14">
                        <img src="../assets/icons/Whatsapp.png" class="p-2 scale-150 md:scale-125" alt="" />
                    </div>
                    <div class="mx-5">
                        <h1 class="text-[#1E0342] font-semibold text-xl lg:text-2xl">
                            WHATSAPP
                        </h1>
                        <a href="" class="text-[#1f162b] font-normal">+62********</a>
                    </div>
                </div>
                <div class="flex py-10">
                    <div class="border rounded-[10rem] border-[#1E0342] p-3 md:min-w-[5rem] md:min-h-[5rem] w-14">
                        <img src="../assets/icons/Gmail.png" class="p-2" alt="" />
                    </div>
                    <div class="mx-5">
                        <h1 class="text-[#1E0342] font-semibold text-xl lg:text-2xl">
                            Email
                        </h1>
                        <a href="" class="text-[#1E0342] font-normal">helloworld@gmail.com</a>
                    </div>
                </div>
            </div>
            <div class="flex-1 justify-end items-end flex-col hidden md:flex">
                <img src="../assets/ContactUs.png" class="mt-20 md:mt-0" alt="" />
            </div>
        </div>
    </section>
    <!-- END CONTACT US -->
</template>