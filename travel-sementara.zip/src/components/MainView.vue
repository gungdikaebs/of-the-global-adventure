<script setup>
import DataCard from '@/components/DataCard.vue'
import { defineProps } from 'vue'
import { ref, computed } from 'vue'

const props = defineProps({
  datas: {
    type: Object,
    required: true
  },
  type: {
    type: String,
    required: true
  }
})

const search = ref('')
const filter = ref('')
const totalData = ref(props.datas.data.length)
const maxShowedData = ref(9)

const loadMore = () => {
  maxShowedData.value += 9
}

const filteredAndSortedItems = computed(() => {
  props.datas.data.sort((a, b) => b.id - a.id)

  const filteredItems = props.datas.data.filter((datas) =>
    datas.placeName.toLowerCase().includes(search.value.toLowerCase())
  )

  if (filter.value === 'alphabetical') {
    return filteredItems.sort((a, b) => a.placeName.localeCompare(b.placeName))
  } else if (filter.value === 'popular') {
    return filteredItems.sort((a, b) => b.rating - a.rating)
  }

  return filteredItems.slice(0, maxShowedData.value)
})
const capitalize = (str) => {
  return str.charAt(0).toUpperCase() + str.slice(1)
}
</script>
<template>
  <main>
    <section
      class="max-w-screen-xl flex mx-auto my-5 justify-between flex-col lg:flex-row px-8 py-2"
    >
      <h1 class="font-semibold text-3xl text-[#0E46A3] mb-2 lg:mb-0">
        {{ capitalize(props.type) }} Page
      </h1>
      <div class="flex flex-row gap-3">
        <input
          type="text"
          :placeholder="'Search ' + capitalize(props.type) + '...'"
          v-model="search"
          class="border bg-transparent border-[#0E46A3] rounded text-[#0E46A3] focus:outline-none placeholder:text-sm placeholder:text-[#0E46A3] px-3 py-1 w-40 lg:w-full"
        />

        <select
          class="rounded bg-[#E1F7F5] text-[#0E46A3] border border-[#0E46A3] focus:outline-none w-18 px-3 py-1"
          name=""
          id=""
          v-model="filter"
        >
          <option class="" value="" hidden>Filter</option>
          <option value="alphabetical">A - Z</option>
          <option value="popular">Popular</option>
        </select>
      </div>
    </section>
    <section class="max-w-screen-xl flex items-center mx-auto">
      <div class="flex flex-col lg:flex-row gap-5 mt-5 flex-auto md:p-3 flex-wrap">
        <!-- card goes here -->
        <DataCard
          v-for="data in filteredAndSortedItems"
          :data="data"
          :key="data.id"
          :type="props.type"
        >
        </DataCard>
      </div>
    </section>
    <div class="flex w-full">
      <button
        @click="loadMore"
        v-if="totalData > maxShowedData"
        class="bg-white text-black text-center mx-auto mb-12 mt-4 p-2 rounded"
      >
        Load More
      </button>
    </div>
  </main>
</template>
