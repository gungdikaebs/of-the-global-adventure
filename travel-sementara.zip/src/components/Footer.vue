<template>
    <footer class="flex flex-col md:flex-row bg-[#1E0342] text-[#E1F7F5] px-10 justify-between">
        <h1 class="flex font-bold text-3xl mt-16 flex-1 md:mt-0 md:items-center md:mx-12">
            OF THE GLOBAL <br />ADVENTURE
        </h1>
        <div class="flex flex-1 justify-between">
            <div class="my-20 md:mr-[5rem] flex-1">
                <h2 class="font-semibold text-xl mb-2 md:mb-4">Navigation</h2>
                <ul class="pl-5">
                    <a href="">
                        <li class="list-disc">Destinations</li>
                    </a>
                    <a href="">
                        <li class="list-disc">Service</li>
                    </a>
                    <a href="">
                        <li class="list-disc">Accomodations</li>
                    </a>
                    <a href="">
                        <li class="list-disc">Activities</li>
                    </a>
                </ul>
            </div>
            <div class="my-20 md:mr-[10rem] w-full flex-1">
                <h2 class="font-semibold text-xl mb-2 md:mb-4 ">Social Media</h2>
                <ul class="pl-5">
                    <li class="list-disc">Instagram</li>
                    <li class="list-disc">Facebook</li>
                </ul>
            </div>
        </div>
    </footer>
</template>