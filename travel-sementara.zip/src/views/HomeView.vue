<script setup>
import DefaultNavbar from '@/components/DefaultNavbar.vue'
import PopularTours from '@/components/PopularTours.vue'
import OurService from '@/components/OurService.vue';
import Activities from '@/components/Activities.vue';
import ContactUs from '@/components/ContactUs.vue';
import Footer from '@/components/Footer.vue';
</script>

<template>

  <DefaultNavbar />
  <main>
    <!-- HERO -->
    <section
      class="max-w-screen-xl flex flex-col flex-wrap mx-auto py-28 bg-[url('./../assets/bg-slogan.svg')] bg-cover bg-center rounded bg-no-repeat">
      <div class="title-hero">
        <h1 class="text-[#E1F7F5] font-bold text-[3rem] md:text-[5rem] mx-16 outline-4 tracking-wide">
          Explore The <br />
          Most Beautiful
        </h1>
        <h1 class="outline-text font-bold text-[3rem] md:text-[5rem] mx-16 tracking-wide">Place</h1>
      </div>
      <a href=""
        class="mx-16 mt-5 text-[#E1F7F5] p-3 bg-[#1E0342] hover:bg-[#0E46A3] duration-300 rounded-md pl-5 w-40 flex">
        Explore Now <img src="./../assets/icons/right.svg" alt="" class="ml-3" />
      </a>
    </section>
    <!-- END HERO -->
    <!-- POPULAR TOURS -->
    <PopularTours></PopularTours>
    <!-- END POPULAR TOURS -->
    <!-- SERVICE -->
    <OurService id="services"></OurService>
    <!-- END SERVICE -->
    <!-- ACTIVITIES -->
    <Activities></Activities>
    <!-- END ACTIVITIES -->
    <!-- CONTACT US -->
    <ContactUs></ContactUs>
    <!-- END CONTACT US -->
    <!-- FOOTER -->
    <Footer></Footer>
    <!-- END FOOTER -->



  </main>
</template>
