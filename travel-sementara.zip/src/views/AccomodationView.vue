<script setup>
import accomodations from '@/assets/json/accomodations.json'
import DefaultNavbar from '@/components/DefaultNavbar.vue';
import MainView from '@/components/MainView.vue';
</script>
<template>
    <DefaultNavbar />
    <MainView :datas="accomodations" type="accomodation"></MainView>
</template>